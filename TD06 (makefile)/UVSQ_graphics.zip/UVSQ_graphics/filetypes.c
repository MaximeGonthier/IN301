[build-menu]
FT_00_LB=_Compiler
FT_00_CM=makeuvsq "%e"
FT_00_WD=
EX_00_LB=_Exécuter
EX_00_CM=./"%e"
EX_00_WD=
