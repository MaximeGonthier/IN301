int bar(int x) {
  return x*x;
}
