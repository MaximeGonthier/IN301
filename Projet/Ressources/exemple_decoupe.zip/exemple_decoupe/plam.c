double foo(int x) {
  return x+0.1;
}
